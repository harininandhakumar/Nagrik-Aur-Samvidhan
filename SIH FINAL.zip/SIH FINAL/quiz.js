const questions = [
    {
        question: "What is the supreme law of India?",
        options: ["The Constitution", "The Parliament", "The President", "The Prime Minister"],
        answer: "The Constitution",
        explanation: "The Constitution is the supreme law of India. It outlines the framework for the political principles and establishes the structure, procedures, powers, and duties of government institutions."
    },
    {
        question: "Who is known as the Father of the Indian Constitution?",
        options: ["Jawaharlal Nehru", "Mahatma Gandhi", "B.R. Ambedkar", "Sardar Patel"],
        answer: "B.R. Ambedkar",
        explanation: "Dr. B.R. Ambedkar is known as the Father of the Indian Constitution for his pivotal role in drafting it."
    },
    {
        question: "When was the Constitution of India adopted?",
        options: ["26 January 1950", "15 August 1947", "26 November 1949", "30 January 1950"],
        answer: "26 November 1949",
        explanation: "The Constitution of India was adopted on 26 November 1949, and it came into effect on 26 January 1950."
    },
    {
        question: "Which part of the Constitution deals with the Directive Principles of State Policy?",
        options: ["Part III", "Part IV", "Part V", "Part VI"],
        answer: "Part IV",
        explanation: "The Directive Principles of State Policy are outlined in Part IV of the Constitution."
    },
    {
        question: "How many fundamental rights are guaranteed by the Indian Constitution?",
        options: ["5", "6", "7", "8"],
        answer: "6",
        explanation: "The Indian Constitution guarantees six fundamental rights to its citizens."
    }
];

let currentQuestionIndex = 0;
let userAnswers = [];
let totalScore = 0;

document.addEventListener('DOMContentLoaded', () => {
    loadQuestion();
    document.getElementById('next-button').addEventListener('click', handleNextButton);
    document.getElementById('finish-button').addEventListener('click', showFinalResults);
    document.getElementById('leaderboard-button').addEventListener('click', showLeaderboard);
    document.getElementById('back-button').addEventListener('click', showQuiz); // This is already correct
});

function handleNextButton() {
    console.log('Next button clicked'); // Debug statement
    // existing code...
}

function showFinalResults() {
    console.log('Finish button clicked'); // Debug statement
    // existing code...
}

function showLeaderboard() {
    console.log('Leaderboard button clicked'); // Debug statement
    // existing code...
}

function showQuiz() {
    console.log('Back button clicked'); // Debug statement
    // existing code...
}


function loadQuestion() {
    if (currentQuestionIndex < questions.length) {
        const question = questions[currentQuestionIndex];
        document.getElementById('question').textContent = question.question;

        const optionsContainer = document.getElementById('options');
        optionsContainer.innerHTML = '';

        question.options.forEach(option => {
            const optionElement = document.createElement('label');
            optionElement.innerHTML = `
                <input type="radio" name="option" value="${option}"> ${option}
            `;
            optionsContainer.appendChild(optionElement);
        });

        // Show or hide buttons based on the question index
        if (currentQuestionIndex === questions.length - 1) {
            document.getElementById('next-button').classList.add('hidden');
            document.getElementById('finish-button').classList.remove('hidden');
        } else {
            document.getElementById('next-button').classList.remove('hidden');
            document.getElementById('finish-button').classList.add('hidden');
        }

        document.getElementById('result-container').classList.add('hidden');
        document.getElementById('leaderboard-container').classList.add('hidden');
    }
}

function handleNextButton() {
    const selectedOption = document.querySelector('input[name="option"]:checked');
    if (selectedOption) {
        const answer = selectedOption.value;
        const correctAnswer = questions[currentQuestionIndex].answer;

        if (answer === correctAnswer) {
            totalScore++;
        }

        userAnswers.push({
            question: questions[currentQuestionIndex].question,
            selectedAnswer: answer,
            correctAnswer: correctAnswer,
            explanation: questions[currentQuestionIndex].explanation
        });

        currentQuestionIndex++;
        loadQuestion();
    } else {
        alert("Please select an option.");
    }
}

function showFinalResults() {
    const resultsList = document.getElementById('results-list');
    resultsList.innerHTML = '';

    // Loop through all questions, not just the ones answered by the user
    questions.forEach((question, index) => {
        const userAnswer = userAnswers.find(answer => answer.question === question.question);

        const resultItem = document.createElement('li');
        resultItem.innerHTML = `
            <strong>Question:</strong> ${question.question}<br>
            <strong>Your Answer:</strong> ${userAnswer ? userAnswer.selectedAnswer : "No answer selected"}<br>
            <strong>Correct Answer:</strong> ${question.answer}<br>
            <strong>Explanation:</strong> ${question.explanation}
        `;
        resultsList.appendChild(resultItem);
    });

    document.getElementById('result-container').classList.remove('hidden');
    document.getElementById('finish-button').classList.add('hidden');
    document.getElementById('leaderboard-button').classList.remove('hidden');
}
