// Law Articles Data
const laws = {
    "article 14": "Article 14 of the Indian Constitution guarantees equality before the law and equal protection of the laws within the territory of India.",
    "article 19": "Article 19 of the Indian Constitution guarantees the citizens of India the right to freedom of speech and expression.",
    "article 21": "Article 21 of the Indian Constitution guarantees protection of life and personal liberty to every individual.",
    "article 32": "Article 32 of the Indian Constitution provides the right to constitutional remedies, allowing individuals to approach the Supreme Court for enforcement of their fundamental rights.",
    "article 44": "Article 44 of the Indian Constitution directs the state to strive towards implementing a Uniform Civil Code for all citizens.",
    "formal written request to a court": "Petition",
    "legal principle that prevents case from being tried again once it is judged": "Double Jeopardy",
    "process of resolving disputes outside of a courtroom": "Mediation",
    "law that has been enacted by a legislative body": "Statute",
    "legal document that outlines the contract": "Agreement",
    "appealing court’s decision to a higher court": "Appeal",
    "legal right to own property": "Title",
    "call a person who initiates a lawsuit": "Plaintiff",
    "formal accusation of a crime": "Indictment",
    // Add more articles and descriptions here
};

// DOM Elements
const chatLog = document.getElementById("chat-log");
const userInput = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");

// Event Listeners
sendBtn.addEventListener("click", handleUserInput);
userInput.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        handleUserInput();
    }
});

// Handle User Input
function handleUserInput() {
    const query = userInput.value.trim();
    if (query === "") return;

    appendMessage("user", query);
    userInput.value = "";

    setTimeout(() => {
        generateBotResponse(query);
    }, 500);
}

// Append Message to Chat Log
function appendMessage(sender, message) {
    const messageContainer = document.createElement("div");
    messageContainer.classList.add("message", sender);

    const avatar = document.createElement("div");
    avatar.classList.add("avatar");
    avatar.innerHTML = sender === "bot" ? '<i class="fas fa-robot"></i>' : '<i class="fas fa-user"></i>';

    const text = document.createElement("div");
    text.classList.add("text");
    text.textContent = message;

    messageContainer.appendChild(avatar);
    messageContainer.appendChild(text);
    chatLog.appendChild(messageContainer);
    chatLog.scrollTop = chatLog.scrollHeight;
}

// Generate Bot Response
function generateBotResponse(query) {
    const lowerCaseQuery = query.toLowerCase();
    const response = laws[lowerCaseQuery] || "Sorry, I don't have information on that article. Please try asking about another article.";

    // Simulate typing effect
    appendTypingIndicator();

    setTimeout(() => {
        removeTypingIndicator();
        appendMessage("bot", response);
    }, 1000);
}

// Typing Indicator
function appendTypingIndicator() {
    const typingIndicator = document.createElement("div");
    typingIndicator.classList.add("message", "bot", "typing");
    typingIndicator.setAttribute("id", "typing-indicator");

    const avatar = document.createElement("div");
    avatar.classList.add("avatar");
    avatar.innerHTML = '<i class="fas fa-robot"></i>';

    const dots = document.createElement("div");
    dots.classList.add("typing-dots");
    dots.innerHTML = `
        <span></span>
        <span></span>
        <span></span>
    `;

    typingIndicator.appendChild(avatar);
    typingIndicator.appendChild(dots);
    chatLog.appendChild(typingIndicator);
    chatLog.scrollTop = chatLog.scrollHeight;
}

function removeTypingIndicator() {
    const typingIndicator = document.getElementById("typing-indicator");
    if (typingIndicator) {
        chatLog.removeChild(typingIndicator);
    }
}
