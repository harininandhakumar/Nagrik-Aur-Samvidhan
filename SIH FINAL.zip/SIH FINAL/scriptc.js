// Constants for speech synthesis and recognition
const synth = window.speechSynthesis;
const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
recognition.lang = 'en-US';  // Set default language
recognition.interimResults = false;
recognition.maxAlternatives = 1;

// Define laws in multiple languages
const laws = {
    "article 1": {
        "en": "India, that is Bharat, shall be a Union of States.",
        "hi": "भारत, अर्थात् इंडिया, राज्यों का एक संघ होगा।",
        "ta": "இந்தியா, அதாவது பாரத், மாநிலங்களின் ஒன்றியம் ஆகும்.",
        "te": "ఇండియా, అంటే భారత్, రాష్ట్రాల సమాఖ్యగా ఉంటుంది.",
        "ml": "ഇന്ത്യ, അതായത് ഭാരത്, സംസ്ഥാനങ്ങളുടെ ഒരു യൂണിയനാണ്."
    },
    
    "article 2": {
        "en": "Admission or establishment of new States.",
        "hi": "नए राज्यों के प्रवेश या स्थापना का प्रावधान।",
        "ta": "புதிய மாநிலங்களின் நுழைவு அல்லது நிறுவல்.",
        "te": "కొత్త రాష్ట్రాల ప్రవేశం లేదా ఏర్పాటు.",
        "ml": "പുതിയ സംസ്ഥാനങ്ങളുടെ പ്രവേശനം അല്ലെങ്കിൽ സ്ഥാപനം."
    },
    "article 3": {
        "en": "Formation of new States and alteration of areas, boundaries, or names of existing States.",
        "hi": "नए राज्यों का निर्माण और मौजूदा राज्यों के क्षेत्रों, सीमाओं या नामों में परिवर्तन।",
        "ta": "புதிய மாநிலங்களின் உருவாக்கம் மற்றும் தற்போதைய மாநிலங்களின் பரப்பளவு, எல்லைகள் அல்லது பெயர்கள் மாற்றம்.",
        "te": "కొత్త రాష్ట్రాల ఏర్పాట్లు మరియు ప్రస్తుత రాష్ట్రాల ప్రాంతాలు, సరిహద్దులు లేదా పేర్లలో మార్పులు.",
        "ml": "പുതിയ സംസ്ഥാനങ്ങളുടെ രൂപീകരണം, നിലവിലെ സംസ്ഥാനങ്ങളുടെ പരിധികൾ, അതിരുകൾ അല്ലെങ്കിൽ പേരുകളുടെ മാറ്റം."
    },
    "article 4": {
        "en": "Laws made under Articles 2 and 3 to provide for the amendment of the First and the Fourth Schedules and supplemental, incidental, and consequential matters.",
        "hi": "अनुच्छेद 2 और 3 के तहत बनाए गए कानून प्रथम और चतुर्थ अनुसूचियों के संशोधन और सहायक, आकस्मिक, और परिणामी मामलों के लिए प्रावधान करते हैं।",
        "ta": "பிரிவு 2 மற்றும் 3 க்கின் கீழ் செய்யப்பட்ட சட்டங்கள் முதல் மற்றும் நான்காம் அட்டவணைகளின் திருத்தத்திற்கும் கூடுதல், உடனடி மற்றும் விளைவுச் சிக்கல்களுக்குமான ஏற்பாடுகளை வழங்குகின்றன.",
        "te": "ఆర్టికల్ 2 మరియు 3 కింద చేసిన చట్టాలు మొదటి మరియు నాల్గవ షెడ్యూల్‌లలో సవరణలు చేయడం మరియు అనుబంధ, అనుబంధ, ఫలిత పరమైన అంశాలకు నిర్వహణను అందిస్తాయి.",
        "ml": "ആർട്ടിക്കിൾ 2, 3 പ്രകാരം നിർമ്മിച്ച നിയമങ്ങൾ ഒന്നാമത്തെയും നാലാമത്തെയും ഷെഡ്യൂളുകളുടെ ഭേദഗതിക്ക്, അനുബന്ധ, പരോക്ഷ, അനന്തര കാര്യങ്ങൾക്കായുള്ള വ്യവസ്ഥകളും നൽകുന്നു."
    },
    "article 5": {
        "en": "Citizenship at the commencement of the Constitution.",
        "hi": "संविधान के प्रारंभ के समय नागरिकता।",
        "ta": "அரசியலமைப்பு அமலுக்கு வந்த நேரத்தில் குடியுரிமை.",
        "te": "రాజ్యాంగ ప్రారంభం సమయానికి పౌరసత్వం.",
        "ml": "ഭാരത ഭരണഘടനയുടെ പ്രാബല്യത്തിലായ സമയത്തെ പൗരത്വം."
    },
    "article 6": {
        "en": "Rights of citizenship of certain persons who have migrated to India from Pakistan.",
        "hi": "उन व्यक्तियों की नागरिकता के अधिकार जो पाकिस्तान से भारत आए हैं।",
        "ta": "பாகிஸ்தானிலிருந்து இந்தியாவிற்கு குடிபெயர்ந்த சில اشخاصுக்கான குடியுரிமை உரிமைகள்.",
        "te": "పాకిస్థాన్ నుండి భారత్‌కు వలస వచ్చిన వ్యక్తుల పౌరసత్వ హక్కులు.",
        "ml": "പാകിസ്ഥാനിൽ നിന്ന് ഇന്ത്യയിലേക്ക് കുടിയേറിയ ചില വ്യക്തികളുടെ പൗരത്വാവകാശങ്ങൾ."
    },
    "article 7": {
        "en": "Rights of citizenship of certain migrants to Pakistan.",
        "hi": "पाकिस्तान गए कुछ प्रवासियों के नागरिकता के अधिकार।",
        "ta": "பாகிஸ்தானுக்கு குடிபெயர்ந்த சிலரின் குடியுரிமை உரிமைகள்.",
        "te": "పాకిస్థాన్‌కు వలస వెళ్లిన కొన్ని వ్యక్తుల పౌరసత్వ హక్కులు.",
        "ml": "പാകിസ്ഥാനിലേക്ക് കുടിയേറിയ ചില വ്യക്തികളുടെ പൗരത്വാവകാശങ്ങൾ."
    },
    "article 8": {
        "en": "Rights of citizenship of certain persons of Indian origin residing outside India.",
        "hi": "भारत के बाहर निवास करने वाले भारतीय मूल के कुछ व्यक्तियों के नागरिकता के अधिकार।",
        "ta": "இந்தியாவிற்குப் வெளியே வசிக்கும் இந்திய நாட்டு மூலத்தின் சிலர்களின் குடியுரிமை உரிமைகள்.",
        "te": "భారత్‌కు వెలుపల నివసించే భారతీయ ఉత్పత్తి యొక్క కొన్ని వ్యక్తుల పౌరసత్వ హక్కులు.",
        "ml": "ഇന്ത്യയിലെ പുറമേ താമസിക്കുന്ന ചില ഇന്ത്യാ ഉറവിടത്തിലുള്ള വ്യക്തികളുടെ പൗരത്വാവകാശങ്ങൾ."
    },
    "article 9": {
        "en": "Persons voluntarily acquiring citizenship of a foreign State.",
        "hi": "स्वेच्छा से विदेशी राज्य की नागरिकता ग्रहण करने वाले व्यक्ति।",
        "ta": "அன்னிய மாநிலத்தின் குடியுரிமையை தன்னிச்சையாகப் பெறும் நபர்கள்.",
        "te": "ప్రేరేపితంగా విదేశీ రాష్ట్రం యొక్క పౌరసత్వం పొందుతున్న వ్యక్తులు.",
        "ml": "വലിച്ചുകേട്ട വിദേശ രാജ്യത്തിന്റെ പൗരത്വം സ്വന്തമാക്കുന്ന വ്യക്തികൾ."
    },
    "article 10": {
        "en": "Continuance of the rights of citizenship.",
        "hi": "नागरिकता के अधिकारों की निरंतरता।",
        "ta": "குடியுரிமையின் உரிமைகளின் தொடர்ச்சி.",
        "te": "పౌరసత్వ హక్కుల కొనసాగింపు.",
        "ml": "പൗരത്വ അവകാശങ്ങളുടെ തുടരവ്."
    }

    // Add other articles as needed...
};

// Set default language
let currentLang = 'en';

// Function to detect language of the query
function detectLanguage(query) {
    const hindiRegex = /[\u0900-\u097F]/;  // Hindi script
    const tamilRegex = /[\u0B80-\u0BFF]/;  // Tamil script
    const teluguRegex = /[\u0C00-\u0C7F]/;  // Telugu script
    const malayalamRegex = /[\u0D00-\u0D7F]/;  // Malayalam script

    if (hindiRegex.test(query)) return "hi";
    if (tamilRegex.test(query)) return "ta";
    if (teluguRegex.test(query)) return "te";
    if (malayalamRegex.test(query)) return "ml";
    return currentLang;  // Use the currently selected language if not detected
}

// Chat functionalities
const chatLog = document.getElementById("chat-log");
const userInput = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");
const voiceBtn = document.getElementById("voice-btn");
const langDropdown = document.getElementById("language-dropdown");

// Event Listeners
sendBtn.addEventListener("click", handleUserInput);
voiceBtn.addEventListener("click", startVoiceRecognition);
userInput.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        handleUserInput();
    }
});

// Handle User Input
function handleUserInput() {
    const query = userInput.value.trim();
    if (query === "") return;

    appendMessage("user", query);
    userInput.value = "";

    setTimeout(() => {
        generateBotResponse(query);
    }, 500);
}

// Append Message to Chat Log
function appendMessage(sender, message) {
    const messageContainer = document.createElement("div");
    messageContainer.classList.add("message", sender);

    const avatar = document.createElement("div");
    avatar.classList.add("avatar");
    avatar.innerHTML = sender === "bot" ? '<i class="fas fa-robot"></i>' : '<i class="fas fa-user"></i>';

    const text = document.createElement("div");
    text.classList.add("text");
    text.textContent = message;

    messageContainer.appendChild(avatar);
    messageContainer.appendChild(text);
    chatLog.appendChild(messageContainer);
    chatLog.scrollTop = chatLog.scrollHeight;
}

// Generate Bot Response with Language Support
function generateBotResponse(query) {
    const lang = detectLanguage(query);  // Detect the language of the query
    const lowerCaseQuery = query.toLowerCase();
    const response = laws[lowerCaseQuery] && laws[lowerCaseQuery][lang] || "Sorry, I don't have information on that article. Please try asking about another article.";

    appendTypingIndicator();

    setTimeout(() => {
        removeTypingIndicator();
        appendMessage("bot", response);
        speak(response, lang);  // Pass the detected language to the speak function
    }, 1000);
}

// Voice Recognition (Start Speech Input)
function startVoiceRecognition() {
    recognition.start();
}

// Handle Voice Recognition Result
recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    appendMessage("user", transcript);
    generateBotResponse(transcript);
};

// Append Typing Indicator
function appendTypingIndicator() {
    const typingIndicator = document.createElement("div");
    typingIndicator.classList.add("message", "bot", "typing");
    typingIndicator.setAttribute("id", "typing-indicator");

    const avatar = document.createElement("div");
    avatar.classList.add("avatar");
    avatar.innerHTML = '<i class="fas fa-robot"></i>';

    const dots = document.createElement("div");
    dots.classList.add("typing-dots");
    dots.innerHTML = '<span></span><span></span><span></span>';

    typingIndicator.appendChild(avatar);
    typingIndicator.appendChild(dots);
    chatLog.appendChild(typingIndicator);
    chatLog.scrollTop = chatLog.scrollHeight;
}

// Remove Typing Indicator
function removeTypingIndicator() {
    const typingIndicator = document.getElementById("typing-indicator");
    if (typingIndicator) {
        chatLog.removeChild(typingIndicator);
    }
}

// Text to Speech (TTS) Function with language support
function speak(text, lang) {
    if (synth.speaking) {
        console.error("Speech synthesis already in progress.");
        return;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    switch (lang) {
        case "hi":
            utterance.lang = 'hi-IN'; break;
        case "ta":
            utterance.lang = 'ta-IN'; break;
        case "te":
            utterance.lang = 'te-IN'; break;
        case "ml":
            utterance.lang = 'ml-IN'; break;
        default:
            utterance.lang = 'en-US'; break;
    }
    synth.speak(utterance);
}
// Handle Language Change
{
document.querySelectorAll("#language-dropdown a").forEach(link => {
    link.addEventListener("click", (event) => {
        event.preventDefault();  // Prevent page reload
        currentLang = event.target.getAttribute("data-lang");  // Update the current language
        console.log("Language changed to:", currentLang);
    });
});
}
