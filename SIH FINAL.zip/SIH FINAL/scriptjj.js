const words = {
    "FUNDAMENTAL RIGHTS": {
        scrambled: "UDNLEMTFANA GRHTSI",
        explanation: "Fundamental Rights are the basic rights guaranteed to every citizen by the Constitution of India."
    },
    "PREAMBLE": {
        scrambled: "REBMLAPE",
        explanation: "The Preamble of the Constitution outlines the fundamental values and principles of the Constitution."
    },
    "SOVEREIGNTY": {
        scrambled: "SNEROVGIETY",
        explanation: "Sovereignty refers to the supreme authority of the state to govern itself without external interference."
    },
    "EQUALITY": {
        scrambled: "QUITALYE",
        explanation: "Equality signifies that every individual is equal before the law and has equal protection and opportunities."
    },
    "AMENDMENT": {
        scrambled: "MENODTRA",
        explanation: "An Amendment is a formal change or addition to the Constitution."
    },
    "DIRECTIVE PRINCIPLES": {
        scrambled: "REETVCIDI EIPRNIPSL",
        explanation: "Directive Principles are guidelines for the framing of laws by the government to ensure social and economic justice."
    },
    "ARTICLE": {
        scrambled: "ALCIRET",
        explanation: "An Article refers to a specific provision or section of the Constitution."
    },
    "DEMOCRACY": {
        scrambled: "MYEOACRDC",
        explanation: "Democracy is a form of government where the people exercise power by voting."
    },
    "JUSTICE": {
        scrambled: "SJITUCE",
        explanation: "Justice refers to the fair treatment and protection of rights for all individuals."
    },
    "LIBERTY": {
        scrambled: "BTLIERY",
        explanation: "Liberty signifies the freedom to act or think without undue restriction."
    }
};

let terms = Object.entries(words);
let currentIndex = 0;
let score = 0;

function showNextWord() {
    if (currentIndex < terms.length) {
        document.getElementById("jumble").innerText = terms[currentIndex][1].scrambled;
        document.getElementById("explanation").innerText = ''; // Clear explanation
    } else {
        document.getElementById("result").innerHTML = `Game Over! Your final score is <strong>${score}/${terms.length}</strong>.`;
        document.getElementById("game").style.display = "none"; // Hide the game interface after it's over
        showRewardButton(); // Show the claim reward button
    }
}

function checkGuess() {
    const guess = document.getElementById("guess").value.toUpperCase();
    const correctWord = terms[currentIndex][0];
    const result = document.getElementById("result");
    const explanation = document.getElementById("explanation");

    if (guess === correctWord) {
        result.innerHTML = "<span class='correct'>Correct!</span>";
        score++;
    } else {
        result.innerHTML = `<span class='wrong'>Wrong!<br>The correct word was: ${correctWord}</span>`;
    }

    // Display explanation regardless of whether the guess was correct or incorrect
    explanation.innerText = words[correctWord].explanation;

    currentIndex++;
    document.getElementById("guess").value = ''; // Clear the input
    showNextWord();
    document.getElementById("score").innerText = `Score: ${score}`;
    explanation.innerText = words[correctWord].explanation;

}

// Show the "Claim Reward" button at the end of the game
function showRewardButton() {
    const rewardSection = document.getElementById("reward-section");
    rewardSection.innerHTML = `<button onclick="downloadReward()">Claim Your Reward</button>`;
}

// Download the reward as a text file
function downloadReward() {
    const rewardText = `Congratulations! You've completed the game with a score of ${score}/${terms.length}. Keep learning and growing!`;
    const blob = new Blob([rewardText], { type: 'text/plain' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.href= 'reward.html'; // Reward file
    link.click();
}

// Initialize the game
showNextWord();
