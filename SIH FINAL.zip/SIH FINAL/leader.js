document.addEventListener('DOMContentLoaded', () => {
    const leaderboard = [
        { username: "Meha", points: 4 },
        { username: "Harini", points: 3 },
        { username: "Anju", points: 5 },
        { username: "Sri", points: 2 },
        { username: "Abi", points: 1 }
    ];

    const leaderboardList = document.getElementById('leaderboard');
    leaderboardList.innerHTML = '';

    // Sort the leaderboard by points in descending order
    leaderboard.sort((a, b) => b.points - a.points);

    leaderboard.forEach((entry, index) => {
        const listItem = document.createElement('li');
        listItem.innerHTML = `
            <span>${index + 1}</span>
            <span>${entry.username}</span>
            <span>${entry.points} / 5</span>
        `;
        leaderboardList.appendChild(listItem);
    });
});
