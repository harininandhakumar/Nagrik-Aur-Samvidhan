const crossword = document.getElementById('crossword');
const acrossClues = document.getElementById('across-clues');
const downClues = document.getElementById('down-clues');
const checkAnswersBtn = document.getElementById('check-answers');
const newGameBtn = document.getElementById('new-game');
const scoreDisplay = document.getElementById('score');

let score = 0;
let currentPuzzle = {};

const puzzles = [
    {
        level: 1,
        grid: [
            {letter: 'C', number: 1}, {letter: 'I'}, {letter: 'T'}, {letter: 'I'}, {letter: 'Z'}, {letter: 'E'}, {letter: 'N'}, {}, {}, {},
            {}, {}, {}, {}, {}, {}, {letter: 'I'}, {}, {}, {},
            {}, {}, {}, {}, {}, {}, {letter: 'G'}, {}, {}, {},
            {}, {}, {}, {}, {}, {}, {letter: 'H'}, {}, {}, {},
            {letter: 'R', number: 2}, {letter: 'I'}, {letter: 'G'}, {letter: 'H'}, {letter: 'T'}, {letter: 'S'}, {}, {}, {letter: 'L', number: 3}, {letter: 'A'},
            {}, {}, {}, {}, {}, {}, {}, {letter: 'I'}, {}, {letter: 'W'},
            {}, {}, {}, {}, {}, {}, {}, {letter: 'B'}, {}, {},
            {}, {}, {}, {}, {letter: 'P', number: 4}, {letter: 'R'}, {letter: 'E'}, {letter: 'A'}, {letter: 'M'}, {letter: 'B'},
            {}, {}, {}, {}, {}, {}, {}, {letter: 'T'}, {}, {},
            {}, {}, {}, {}, {}, {}, {}, {letter: 'S'}, {}, {}
        ],
        acrossClues: {
            1: 'A member of a state or nation',
            2: 'Part of the Constitution guaranteeing fundamental freedoms',
            3: 'The introductory statement of the Constitution',
            4: 'A statement that starts the Constitution',
        },
        downClues: {
            1: 'Rights protected by the Constitution',
            4: 'A fundamental duty or entitlement of citizens',
        },
        answers: {
            '1-across': 'CITIZEN',
            '2-across': 'RIGHTS',
            '3-across': 'LAW',
            '4-across': 'PREAMBLE',
            '1-down': 'RIGHTS',
            '4-down': 'LIBERTY'
        }
    },
    // Add more Constitution-related puzzles here
];

function startGame(level = 1) {
    const puzzle = puzzles.find(p => p.level === level);
    currentPuzzle = puzzle;
    renderPuzzle(puzzle);
}

function renderPuzzle(puzzle) {
    crossword.innerHTML = '';
    acrossClues.innerHTML = '';
    downClues.innerHTML = '';

    puzzle.grid.forEach((cellData, index) => {
        const cell = document.createElement('div');
        if (cellData.letter) {
            cell.contentEditable = true;
            cell.textContent = '';
            cell.setAttribute('data-letter', cellData.letter.toUpperCase());
        }
        if (cellData.number) {
            cell.setAttribute('data-number', cellData.number);
        }
        crossword.appendChild(cell);
    });

    for (let key in puzzle.acrossClues) {
        const clue = document.createElement('div');
        clue.textContent = `${key}: ${puzzle.acrossClues[key]} (Across)`;
        acrossClues.appendChild(clue);
    }

    for (let key in puzzle.downClues) {
        const clue = document.createElement('div');
        clue.textContent = `${key}: ${puzzle.downClues[key]} (Down)`;
        downClues.appendChild(clue);
    }
}

function checkAnswers() {
    let correctAnswers = 0;
    for (let key in currentPuzzle.answers) {
        const [number, direction] = key.split('-');
        const cells = [...crossword.children];
        const answer = currentPuzzle.answers[key];
        let userAnswer = '';

        if (direction === 'across') {
            const startIndex = (number - 1) * 10;
            userAnswer = cells.slice(startIndex, startIndex + answer.length)
                              .map(cell => cell.textContent.trim().toUpperCase())
                              .join('');
        } else if (direction === 'down') {
            const startIndex = number - 1;
            for (let i = 0; i < answer.length; i++) {
                userAnswer += cells[startIndex + i * 10].textContent.trim().toUpperCase();
            }
        }

        if (userAnswer === answer) {
            correctAnswers++;
        }
    }

    score += correctAnswers;
    scoreDisplay.textContent = `Score: ${score}`;
alert(`You got ${correctAnswers} correct answers!`);
}

checkAnswersBtn.addEventListener('click', checkAnswers);
newGameBtn.addEventListener('click', () => startGame(1));

// Start with the first level
startGame();